//
//  ContentView.swift
//  TRM
//
//  Created by RUAA Al-Oneizi on 31/03/2022.
//

import SwiftUI

struct MainPage: View {
    var body: some View {
        ZStack{
            Image("logo bg")
            frame(width: 600, height: 800)
            
            
            Text("Track Your Migrain")
                .font(.largeTitle)
                .fontWeight(.light)
                .foregroundColor(Color(hue: 1.0, saturation: 0.041, brightness: 0.305))
                .multilineTextAlignment(.center)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MainPage()
            
    }
}
