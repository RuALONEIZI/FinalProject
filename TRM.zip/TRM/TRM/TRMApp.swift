//
//  TRMApp.swift
//  TRM
//
//  Created by Raghad Al-Oneizi on 31/03/2022.
//

import SwiftUI

@main
struct TRMApp: App {
    var body: some Scene {
        WindowGroup {
        MainPage()
        }
    }
}
